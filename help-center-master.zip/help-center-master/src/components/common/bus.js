import Vue from 'vue';

// 使用 Event Bus,实现兄弟组件之间传值
const bus = new Vue();

export default bus;
